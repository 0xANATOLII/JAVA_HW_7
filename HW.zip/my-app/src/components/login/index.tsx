
const Login = () => {
    return (
        <>
            <h1 className = "text-3xl">Login Page</h1>
        </>
    )
}
export default Login;