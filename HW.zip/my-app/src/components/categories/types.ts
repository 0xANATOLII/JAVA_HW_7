export interface ICategoryCreate {
    name: string;
    base64: string;
    description: string;
};