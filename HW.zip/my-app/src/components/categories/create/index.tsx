import CategoryCreatePage from "./CategoryCretePage";

export default CategoryCreatePage;