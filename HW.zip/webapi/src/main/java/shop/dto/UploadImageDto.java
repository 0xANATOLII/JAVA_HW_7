package shop.dto;

import lombok.Data;

@Data
public class UploadImageDto {
    private String base64;
}
